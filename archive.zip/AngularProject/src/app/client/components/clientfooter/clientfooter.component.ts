import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'clientfooter',
  templateUrl: './clientfooter.component.html',
  styleUrls: ['./clientfooter.component.css']
})
export class ClientFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
