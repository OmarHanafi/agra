package com.agra.dao;

import com.agra.entity.User;

public interface UserDAO {

	public User getUser(String username);

}
